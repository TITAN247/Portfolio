# project.py
import pandas as pd

p = pd.DataFrame({
    "Name": ["Aman", "Rahul", "Priya", "Aman", "Rahul"],
    "Department": ["IT", "HR", "IT", "HR", "IT"],
    "Salary": [50000, 40000, 60000, 45000, 55000],
    "Age": [25, 28, 24, 30, 27]
})

print(p)
print(p.groupby("Department").mean(numeric_only=True))
