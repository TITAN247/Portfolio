
# Personal Finance Manager 

class FinanceManager:
    def __init__(self):
        self.name=""
        self.__pin=""
        self.__balance=0
        self.salary=0
        self.budget=0
        self.expenses=[]
        self.history=[]
        self.account=False

    @property
    def balance(self):
        return self.__balance

    @property
    def pin(self):
        return self.__pin

    @pin.setter
    def pin(self,value):
        self.__pin=value

    def create_account(self):
        self.name=input("Name: ")
        age=int(input("Age: "))
        if age<18:
            print("Age must be 18+"); return
        self.salary=float(input("Monthly Salary: "))
        self.budget=float(input("Monthly Budget: "))
        self.__balance=float(input("Opening Balance: "))
        self.pin=input("Create 4-digit PIN: ")
        self.account=True
        self.history.append("Account Created")
        print("Account Created Successfully!")

    def login(self):
        if not self.account:
            print("Create account first."); return False
        p=input("Enter PIN: ")
        if p==self.pin:
            return True
        print("Wrong PIN")
        return False

    def deposit(self):
        amt=float(input("Deposit Amount: "))
        self.__balance+=amt
        self.history.append(f"Deposit ₹{amt}")

    def withdraw(self):
        amt=float(input("Withdraw Amount: "))
        if amt<=self.__balance:
            self.__balance-=amt
            self.history.append(f"Withdraw ₹{amt}")
        else:
            print("Insufficient Balance")

    def add_expense(self):
        cat=input("Category: ")
        item=input("Item: ")
        pay=input("Payment(Cash/UPI/Card): ")
        amt=float(input("Amount: "))
        date=input("Date: ")
        if amt>self.__balance:
            print("Insufficient Balance"); return
        self.__balance-=amt
        self.expenses.append({"cat":cat,"item":item,"pay":pay,"amt":amt,"date":date})
        self.history.append(f"Expense {item} ₹{amt}")

    def show_expenses(self):
        if not self.expenses:
            print("No Expenses"); return
        for i,e in enumerate(self.expenses,1):
            print(i,e["item"],e["cat"],e["amt"],e["pay"],e["date"])

    def total_expense(self):
        return sum(e["amt"] for e in self.expenses)

    def report(self):
        print("\n----- REPORT -----")
        print("Name:",self.name)
        print("Salary:",self.salary)
        print("Budget:",self.budget)
        print("Bank Balance:",self.balance)
        print("Total Expense:",self.total_expense())
        print("Remaining Salary:",self.salary-self.total_expense())
        print("Remaining Budget:",self.budget-self.total_expense())
        if self.total_expense()>self.budget:
            print("Warning: Budget Exceeded!")

    def search_category(self):
        c=input("Category: ").lower()
        for e in self.expenses:
            if e["cat"].lower()==c:
                print(e)

    def delete_expense(self):
        self.show_expenses()
        if not self.expenses:return
        n=int(input("Expense No: "))-1
        if 0<=n<len(self.expenses):
            self.__balance+=self.expenses[n]["amt"]
            self.history.append("Deleted "+self.expenses[n]["item"])
            del self.expenses[n]

    def history_show(self):
        for h in self.history:
            print(h)

fm=FinanceManager()

while True:
    print("""
========== PERSONAL FINANCE MANAGER ==========
1.Create Account
2.Login
3.Deposit
4.Withdraw
5.Add Expense
6.Show Expenses
7.Search Category
8.Delete Expense
9.Report
10.Transaction History
11.Exit
""")
    ch=input("Choice: ")

    if ch=="1":
        fm.create_account()
    elif ch=="2":
        if fm.login():
            print("Login Successful")
    elif ch=="3":
        if fm.login(): fm.deposit()
    elif ch=="4":
        if fm.login(): fm.withdraw()
    elif ch=="5":
        if fm.login(): fm.add_expense()
    elif ch=="6":
        fm.show_expenses()
    elif ch=="7":
        fm.search_category()
    elif ch=="8":
        if fm.login(): fm.delete_expense()
    elif ch=="9":
        fm.report()
    elif ch=="10":
        fm.history_show()
    elif ch=="11":
        print("Thank You")
        break
    else:
        print("Invalid Choice")
